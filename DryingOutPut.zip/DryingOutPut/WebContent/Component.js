sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"Testapplication/model/models",
	"Testapplication/MyRouter"
], function(UIComponent, Device, models,router) {
	"use strict";

	return UIComponent.extend("Testapplication.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			/**
			 * called the service to bibd the data to Output chamber of Drying 
			 **/
			var ServiceUrl = "/sap/opu/odata/SAP/ZGW_VN_QNTORY_DRY_HUM_SRV/"
			var	dryingService = '';
			if (window.location.hostname == "localhost") {
				dryingService =  "proxy" + ServiceUrl;  // proxy setting when running at localhost
			}else{
				dryingService =  ServiceUrl;
			}
			/*
			 * Odata Model call to set the service, The service set with the alias name, 
			 *  as application already contains the mainService
			 */
			var userId = "IN_GURUM";
			var password = "2wsx@WSX";
			var dryingModel = new sap.ui.model.odata.ODataModel(dryingService,true,userId,password);
			this.setModel(dryingModel,"dryOutputModel")
			this.getRouter().initialize();
		}
	});
});